﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class edit : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\aarti\siddhi\main\App_Data\db.mdf;Integrated Security=True;User Instance=True");
       SqlCommand com;
       string fname, lname, addr, email, mobile, user, pass;
       
       protected void Page_Load(object sender, EventArgs e)
       {
           
           con.Open();
           if (Session["name"] == null)
           {
               Response.Redirect("login.aspx");
           }

           if (!IsPostBack)
           {
               getDetails();
           }
       }
        protected void btnRegSubmit_Click(object sender, ImageClickEventArgs e)
        {
            
                string addr = txtAddress.Text;
                string mob = txtMob.Text;
                string email = txtEmail.Text;
                string password = pass;
                string strUpdate = "update reg set c_address=@addr, c_mob=@mob, c_email=@email where c_uname=@uname";
                com = new SqlCommand(strUpdate, con);
                com.Parameters.Add("addr", addr);
                com.Parameters.Add("mob", mob);
                com.Parameters.Add("email", email);
              com.Parameters.Add("uname", Session["name"].ToString());
                //com.Parameters.Add("uname", uname);
                com.ExecuteNonQuery();
         
            getDetails();
            //Response.Redirect("login.aspx");

           
        }

        protected void btnRegReset_Click(object sender, ImageClickEventArgs e)
        {
            txtAddress.Text = "";
            txtEmail.Text = "";
            txtMob.Text = "";
            txtUname.Text = "";
           
        }
        void getDetails()
        {
            string str = "select * from reg where c_uname='" + Session["name"] + "'";
            com = new SqlCommand(str, con);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            fname = ds.Tables[0].Rows[0]["c_fname"].ToString();
            lname = ds.Tables[0].Rows[0]["c_lname"].ToString();
            addr = ds.Tables[0].Rows[0]["c_address"].ToString();
            email = ds.Tables[0].Rows[0]["c_email"].ToString();
            mobile = ds.Tables[0].Rows[0]["c_mob"].ToString();
            user = ds.Tables[0].Rows[0]["c_uname"].ToString();
            pass = ds.Tables[0].Rows[0]["c_password"].ToString();

            txtFirstName.Text = fname;
            txtLastName.Text = lname;
            txtAddress.Text = addr;
            txtEmail.Text = email;
            txtMob.Text = mobile;
            txtUname.Text = user;
            //txtPass.Text = pass;
        }

    }
