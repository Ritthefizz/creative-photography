﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Redirect("registration.aspx");
    }
    protected void btnLogSubmit_Click(object sender, ImageClickEventArgs e)
    {

        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        objConn.Open();
        SqlCommand cmd = new SqlCommand("Select COUNT(*)FROM reg WHERE c_uname='" + txtName.Text + "'and c_password='" + txtPass.Text + "' ");
        cmd.Connection = objConn;

        int OBJ = Convert.ToInt32(cmd.ExecuteScalar());
        if (OBJ > 0)
        {
            Session["name"] = txtName.Text;
            Response.Redirect("work.aspx");
        }
        else
        { Session["name"] = txtName.Text;
            Label8.Text = "Invalid Username or Password...Please Try again";
            //this.Label8.ForeColor = Color.Red;
        }

    }

    protected void lnk_changepassword_Click(object sender, EventArgs e)
    {
        //Session["name"] = txtName.Text;
        //Response.Redirect("changepassword.aspx");
    }
    protected void lnk_update_Click(object sender, EventArgs e)
    {
        //Session["name"] = txtName.Text;
        //Response.Redirect("update.aspx");
    }


    protected void ClearALL()
    {
        txtPass.Text = "";
        txtName.Text = "";


    }

    protected void btnLogReset_Click(object sender, ImageClickEventArgs e)
    {
        ClearALL();
    }
}