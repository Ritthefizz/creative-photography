﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Drawing;

using System.Configuration;
using System.Net.Mail;

public partial class Enquiry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnRegSubmit_Click(object sender, ImageClickEventArgs e)
    {
        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        objConn.Open();
        SqlCommand cmd = new SqlCommand();
        cmd = objConn.CreateCommand();
        String strInsertQry;
        strInsertQry = "insert into Enquiry(Ename,Econtact,Email,Eenquiry) values (@Ename,@Econtact,@Email,@Eenquiry)";
        cmd.CommandText = strInsertQry;
        String Ename, Econtact, Email, Eenquiry;


        Ename = txtname.Text;
        Econtact = txtcontact.Text;
        Email = txtmail.Text;
        Eenquiry = txtenquiry.Text;





        cmd.Parameters.AddWithValue("@Ename", Ename);
        cmd.Parameters.AddWithValue("@Econtact", Econtact);
        cmd.Parameters.AddWithValue("@Email", Email);
        cmd.Parameters.AddWithValue("@Eenquiry", Eenquiry);

        
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        objConn.Close();
        MailMessage mail = new MailMessage();
        mail.To.Add(Email);
        mail.From = new MailAddress("creativephotographywebsite@gmail.com");

        mail.Subject = "Order Details";
        mail.Body = Eenquiry;
        mail.IsBodyHtml = true;


        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        //'Or Your SMTP Server Address
        smtp.Credentials = new System.Net.NetworkCredential("creativephotographywebsite@gmail.com", "creative@2131");
        //Or your Smtp Email ID and Password
        smtp.EnableSsl = true;
        smtp.Send(mail);

        Label1.ForeColor = Color.Aqua;
        Label1.Text = "Thanks for interacting with us, you will get mail soon on your provided mail id";

    }



    protected void ClearALL()
    {
        txtmail.Text = "";
        txtcontact.Text = "";
        txtname.Text = "";
        txtenquiry.Text = "";
        Response.Redirect("Enquiry.aspx");

    }

    protected void  btnRegReset_Click(object sender, ImageClickEventArgs e)
{
         ClearALL();
}
}
