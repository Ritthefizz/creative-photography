﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class adminsite_AddNewProduct : System.Web.UI.Page
{
    int catid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ownername"] == null)
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        int catid = Convert.ToInt32(ddlcatid.SelectedValue);


        string photoname = Request.Form["photoname"];
        string photodesc = Request.Form["photodesc"];
        //int price = Convert.ToInt32(Request.Form["price"]);


        string folderpath = "";


        //string subcat = "";

        if (catid == 1)
        {
            folderpath = "~/images/pf";
            // subcat=@"~\images\categoryproducts\breakfast\";
        }
        else if (catid == 2)
        {
            folderpath = "~/images/wedding/";
            //subcat=@"~\images\categoryproducts\maincourse\";
            //string path = "~\\ path \\" + filename.Trim();
        }
        else if (catid == 3)
        {
            folderpath = "~/images/nature/";
            //  subcat=@"~\images\categoryproducts\chinese\";
        }
        else if (catid == 4)
        {
            folderpath = "~/images/materninty/";
            //    subcat=@"~\images\categoryproducts\deserts\";
        }
        else if (catid == 5)
        {
            folderpath = "~/images/wildlife/";
            //    subcat=@"~\images\categoryproducts\deserts\";
        }
        else if (catid == 6)
        {
            folderpath = "~/images/other/";
            //    subcat=@"~\images\categoryproducts\deserts\";
        }
        string filename = "";
        if (photoimage.HasFile)
        {
            filename = photoimage.FileName.ToString();

            photoimage.SaveAs(Server.MapPath(folderpath + filename));

        }

        /* if (Request.QueryString["FileName"] != null)
        {
            // Read the file and convert it to Byte Array
            string filePath = "C:\\images\\";
            string filename = Request.QueryString["FileName"];
            string contenttype = "image/" +  Path.GetExtension(filename).Replace(".",""); 
            FileStream fs = new FileStream(filePath + filename, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);
            br.Close();
            fs.Close();

            //Write the file to response Stream
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = contenttype;
            Response.AddHeader("content-disposition", "attachment;filename=" + filename);
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.End();


        }

        */
        string photourl = folderpath + filename;

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        //"Data Source=DELL\SQLEXPRESS1;Initial Catalog=F:\SPOTLIGHTIT\APP_DATA\FOOD.MDF;Integrated Security=True");

        con.Open();

        SqlCommand cmd = con.CreateCommand();

        cmd.CommandText = @"insert into allphotos(catid,photoname,photourl,photodesc) values (@catid,@photoname,@photourl,@photodesc)";
        cmd.Connection = con;


        cmd.Parameters.AddWithValue("catid", catid);
        cmd.Parameters.AddWithValue("photoname", photoname);
        cmd.Parameters.AddWithValue("photourl", photourl);
        cmd.Parameters.AddWithValue("photodesc", photodesc);
   
        cmd.ExecuteNonQuery();


        Response.Redirect("adminpage.aspx");

    }
   
}