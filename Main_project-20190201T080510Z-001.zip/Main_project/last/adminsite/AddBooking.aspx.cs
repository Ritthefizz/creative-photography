﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class adminsite_AddBooking : System.Web.UI.Page
{
    int catid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ownername"] == null)
        {
            Response.Redirect("Adminlogin.aspx");
        }
    }
    protected void btn1_Click(object sender, EventArgs e)
    {
        
        int catid = Convert.ToInt32(DropDownList1.SelectedValue);
        Session["category_type"] =(DropDownList2.SelectedValue);
        Session ["cost"] = Request.Form["cost"];
        string outfit_changes = Request.Form["outfit_changes"];
        string photographs = Request.Form["photographs"].ToString();
        Session ["duration"] = Request.Form["duration"];


        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");


        con.Open();

        SqlCommand cmd = con.CreateCommand();
        cmd.CommandText = @"insert into book(catid,category_type,cost,outfit_changes,photographs,duration) values (@catid,@category_type,@cost,@outfit_changes,@photographs,@duration)";
        cmd.Connection = con;


        cmd.Parameters.AddWithValue("catid", catid);
        cmd.Parameters.AddWithValue("category_type", Session["category_type"]);
        cmd.Parameters.AddWithValue("cost", Session["cost"]);
        cmd.Parameters.AddWithValue("outfit_changes", outfit_changes);
        cmd.Parameters.AddWithValue("photographs", photographs);
        cmd.Parameters.AddWithValue("duration", Session["duration"]);
        
        
        cmd.ExecuteNonQuery();
        con.Close();
       
    //    Response.Redirect("adminpage.aspx");


    }
}
