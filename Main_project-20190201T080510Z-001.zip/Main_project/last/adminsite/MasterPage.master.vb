﻿
Partial Class admin_MasterPage
    Inherits System.Web.UI.MasterPage
End Class

