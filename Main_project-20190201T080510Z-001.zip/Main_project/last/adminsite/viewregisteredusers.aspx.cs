﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data ;
using System.Data.SqlClient;


public partial class admin_viewregisteredusers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ownername"] ==null)
            Response.Redirect("Adminlogin.aspx");
        
        //string strconn;
        //strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
        //SqlConnection  objConn =new SqlConnection(strconn);
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");

        string strQry = " select c_id from reg";
        SqlDataAdapter objadapter= new SqlDataAdapter(strQry, con);
        DataSet objdataset =new DataSet();
        objadapter.Fill(objdataset, "reg");
        GridView1.AutoGenerateSelectButton = true;
        GridView1.DataSource = objdataset;
        GridView1.DataBind();


    }
    protected void ImgBtnDelete_Click(object sender, ImageClickEventArgs e)
    {
        
        //string strconn;
        //strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
        //SqlConnection objConn =new SqlConnection(strconn);
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
            int custID = Convert.ToInt32 (GridView1.SelectedValue);
        string strqury  = "delete from reg where c_id=" +custID ;
        SqlCommand objcmd =new SqlCommand(strqury, con);
        GridView1.DataBind();
  
        if (custID ==null)
            lblmsg.Text=("Please Select Record");
        else
        {
            con.Open();
            int intReco  = objcmd.ExecuteNonQuery();
            if (intReco > 0 )
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Customer Record Deleted Successfully";
               }
            
        }
        con.Close();

    }
protected void  GridView1_SelectedIndexChanged(object sender, EventArgs e)
{
        //string strconn;
        //strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
        //SqlConnection objConn =new SqlConnection(strconn);
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");

        int custID =Convert.ToInt32 ( GridView1.SelectedValue);
        string strqury = " select * from reg where c_id =@c_id";
        SqlCommand objcmd=new SqlCommand(strqury, con);
        objcmd.Parameters.AddWithValue("@c_id", custID);
        string strCustDetails ;
        con.Open();
        SqlDataReader objreader = objcmd.ExecuteReader();
        objreader.Read();
        lblmsg.Visible = true;
        strCustDetails = "<br>" + "Customer id  - " + objreader[0] + "<br><br>";
        strCustDetails += "Customer First name   - " + objreader[1] + "<br><br>";
        strCustDetails += "Customer Last Name  - " + objreader[2] + "<br><br>";
        strCustDetails += "Customer Address  - " + objreader[3] + "<br><br>";
        strCustDetails += "Customer Mobile No.  - " + objreader[4] + "<br><br>";
        strCustDetails += "Customer Email Id   - " + objreader[5] + "<br><br>";
        strCustDetails += "Customer User Name  - " + objreader[6] + "<br><br>";
        strCustDetails += "Customer Secret Q.  - " + objreader[7] + "<br><br>";

        lblmsg.Text = strCustDetails;

        con.Close();

}
}