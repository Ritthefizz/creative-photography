﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class adminsite_booking : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ownername"] == null)
            Response.Redirect("adminlogin.aspx");

        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        string str = "select ordid from confirm_order";
        SqlDataAdapter da = new SqlDataAdapter(str, conn);
        DataSet ds = new DataSet();
        da.Fill(ds);

        GridView1.AutoGenerateSelectButton = true;
        GridView1.DataSource = ds;
        GridView1.DataBind();



    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        int ordid = Convert.ToInt32(GridView1.SelectedValue);
        string str = "select * from confirm_order where ordid=" + ordid;
        SqlCommand com = new SqlCommand(str, conn);
        com.Parameters.AddWithValue("@ordid", ordid);
        conn.Open();
        string strDetails;

        SqlDataReader dr = com.ExecuteReader();
        dr.Read();
        lblmsg.Visible = true;

        strDetails = "<br>" + " " + dr[0] + "<br><br>";
        strDetails += "cust_emailid: " + dr[1] + "<br><br>";
        strDetails += "category: " + dr[2] + "<br><br>";
        strDetails += "category_name: " + dr[3] + "<br><br>";
        strDetails += "cost: " + dr[4] + "<br><br>";
        strDetails += "duration: " + dr[5] + "<br><br>";
        strDetails += "event_date: " + dr[6] + "<br><br>";
        strDetails += "event_address : " + dr[7] + "<br><br>";
        strDetails += "mobile_no : " + dr[8] + "<br><br>";

        lblmsg.Text = strDetails;
        conn.Close();




    }


    protected void ImgBtnDelete_Click(object sender, ImageClickEventArgs e)
    {
        //string strconn;
        //strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
        //SqlConnection objConn = new SqlConnection(strconn);
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        int ordid = Convert.ToInt32(GridView1.SelectedValue);
        string strqury = "delete from confirm-order where ordid=" + ordid;
        SqlCommand objcmd = new SqlCommand(strqury, conn);


        if (ordid == null)
            lblmsg.Text = "Please Select Record";
        else
        {
            conn.Open();
            int intReco = objcmd.ExecuteNonQuery();
            if (intReco > 0)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Booking Record Deleted Successfully";
            }

        }
        conn.Close();

    }
}