﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration ;

public partial class admin_fadminlogin : System.Web.UI.Page
{
  
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void claerAll()
    {
        txtOwnerName.Text = "";
        txtPassword.Text = "";
        txtOwnerName.Focus();
    }

    

protected void  btnSubmit_Click(object sender, ImageClickEventArgs e)
{
//        string strconn;
//        strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
//        SqlConnection objConn =new SqlConnection(strconn);
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");

        string strSelectQry = "Select * from tblOwner where owner_name=@OwnerName And owner_pass=@OwnerPass";
        SqlCommand objCmd =new SqlCommand(strSelectQry, con);
        objCmd.Parameters.AddWithValue("@OwnerName", txtOwnerName.Text);
        objCmd.Parameters.AddWithValue("@OwnerPass", txtPassword.Text);
        con.Open();
         
         SqlDataReader objReader = objCmd.ExecuteReader();
    //'Data.CommandBehavior.SingleRow);

        if (objReader.Read())
        {
            Session["ownername"] = txtOwnerName.Text;
            Response.Redirect("AdminPage.aspx");
        }
        else{
            lblerror.Text = "Please Enter your correct user name or Password";
           txtOwnerName.Text = "";
            txtPassword.Text = "";
            txtOwnerName.Focus();
            Session.Clear();
        }
        con.Close();
}

protected void  btnReset_Click1(object sender, ImageClickEventArgs e)
{
    claerAll();
}
}



  

  

    

