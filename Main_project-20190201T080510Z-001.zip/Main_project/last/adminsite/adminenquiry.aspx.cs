﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System;
using System.Configuration;
using System.Net.Mail;


public partial class admin_fadminenquiry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ownername"] == null)
        {
            Response.Redirect("AdminLogin.aspx");
        }
        else
        {
            //string strconn ;
            //strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
            //SqlConnection objConn =new SqlConnection(strconn);
            SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
            string strqury = " select id,Email,Eenquiry from Enquiry ";
            SqlDataAdapter objadapter = new SqlDataAdapter(strqury, objConn);
            DataSet objDataset = new DataSet();
            objadapter.Fill(objDataset, "Enquiry");
            GridView1.AutoGenerateSelectButton = true;
            GridView1.DataSource = objDataset;
            GridView1.DataBind();

        }
    }

    protected void GridView1_PageIndexChanging(Object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }


    protected void btnSendEmail_Click(object sender, ImageClickEventArgs e)
    {
        MailMessage mail = new MailMessage();
        mail.To.Add(txtTo.Text);
        mail.From = new MailAddress("creativephotographywebsite@gmail.com");
        mail.Subject = txtSubject.Text;
        mail.Body = txtMessage.Text;
        mail.IsBodyHtml = true;

        //'Attach file using FileUpload Control and put the file in memory stream
        if (FileUpload1.HasFile)
        {
            mail.Attachments.Add(new Attachment(FileUpload1.PostedFile.InputStream, FileUpload1.FileName));
        }

        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";


        System.Net.NetworkCredential network = new System.Net.NetworkCredential();
        network.UserName = "creativephotographywebsite@gmail.com";
        network.Password = "creative@2131";
        smtp.UseDefaultCredentials = true;
        smtp.Credentials = network;
        smtp.Port = 587;
        smtp.EnableSsl = true;
        smtp.Send(mail);

        lblmail.Text = "Your Mail Succesfully got Send to" + " " + txtTo.Text;
        txtFrom.Text = "";
        txtMessage.Text = "";
        txtSubject.Text = "";
        txtTo.Text = "";
        GridView1.Visible = true;

    }
    protected void btnDelEnq_Click1(object sender, ImageClickEventArgs e)
    {

        //  string  strconn ;
        // strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
        // SqlConnection objConn=new SqlConnection(strconn);
        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");

        int enqid = Convert.ToInt32(GridView1.SelectedValue);
        string strqury = "delete from Enquiry where Eenquiry='" + enqid + "'";
        SqlCommand objcmd = new SqlCommand(strqury, objConn);

        if (enqid == null)
            lblmail.Text = "Please Select Record ";
        else
        {
            objConn.Open();


            int intReco = objcmd.ExecuteNonQuery();
            if (intReco > 0)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Enquiry Deleted Successfully";
            }
        }


        objConn.Close();
    }
    protected void GridView1_SelectedIndexChanging(Object sender, System.Web.UI.WebControls.GridViewSelectEventArgs e)
    {
        GridView1.PageIndex = e.NewSelectedIndex;
        GridView1.DataBind();
    }
    protected void GridView1_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        
        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        int enqid = Convert.ToInt32(GridView1.SelectedValue);
        string strqury = " select * from Enquiry where id =@id";
        SqlCommand objcmd = new SqlCommand(strqury, objConn);
        objcmd.Parameters.AddWithValue("@id", enqid);
        string strEnqDetails;
        objConn.Open();
        SqlDataReader objreader = objcmd.ExecuteReader();
        objreader.Read();
        lblmsg.Visible = true;

        strEnqDetails = "Enquiry id   - " + objreader[0] + "<br>";
        strEnqDetails += objreader[1] + "<br>";
        strEnqDetails += objreader[2] + "<br>";
        strEnqDetails += objreader[3] + "<br>";
        txtTo.Text = objreader[3].ToString();
        strEnqDetails += " Enquiry  - " + objreader[4] + "<br><br>";

        txtSubject.Text = " :";
        txtMessage.Text = " :";
        lblmsg.Text = strEnqDetails;
        GridView1.Visible = false;
    }
    protected void btnEmailReset_Click(object sender, ImageClickEventArgs e)
    {
        //txtFrom.Text = "";
        txtMessage.Text = "";
        txtSubject.Text = "";
        txtTo.Text = "";
    }
}