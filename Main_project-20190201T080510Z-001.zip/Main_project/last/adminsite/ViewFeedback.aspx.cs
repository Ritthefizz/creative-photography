﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration ;

public partial class fViewFeedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["ownername"] == null)
            Response.Redirect("AdminLogin.aspx");

        //string strconn;
        //strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
        // SqlConnection  objConn =new SqlConnection(strconn);

        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        string strQry = " select id from Feedback";
        SqlDataAdapter objadapter = new SqlDataAdapter(strQry, objConn);
        DataSet objdataset = new DataSet();
        objadapter.Fill(objdataset, "Feedback");
        GridView2.AutoGenerateSelectButton = true;
        GridView2.DataSource = objdataset;
        GridView2.DataBind();
    }
    protected void ImgBtnDelete_Click(object sender, ImageClickEventArgs e)
    {
        // string strconn;
        //strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
        //SqlConnection objConn =new SqlConnection(strconn);
        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        int fbID = Convert.ToInt32(GridView2.SelectedValue);
        string strqury = "delete from Feedback where id=" + fbID;
        SqlCommand objcmd = new SqlCommand(strqury, objConn);


        if (fbID == null)
            lblmsg.Text = "Please Select Record";
        else
        {
            objConn.Open();
            int intReco = objcmd.ExecuteNonQuery();
            if (intReco > 0)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Feedback Record Deleted Successfully";
            }

        }
        objConn.Close();
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {


        // string strconn;
        //strconn = ConfigurationManager.ConnectionStrings["dbConnectionString"].ToString();
        //SqlConnection objConn =new SqlConnection(strconn);
        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        int fb_id = Convert.ToInt32(GridView2.SelectedValue);
        string strqury = " select * from Feedback where id =" + fb_id;

        SqlCommand objcmd = new SqlCommand(strqury, objConn);
        objcmd.Parameters.AddWithValue("@id", fb_id);

        string strCustDetails;
        objConn.Open();
        SqlDataReader objreader = objcmd.ExecuteReader();
        objreader.Read();
        lblmsg.Visible = true;
        strCustDetails = "<br>" + "Feedback id  - " + objreader[0] + "<br><br>";
        strCustDetails += "Name   - " + objreader[1] + "<br><br>";
        strCustDetails += "Email  - " + objreader[2] + "<br><br>";
        strCustDetails += "Feedback  - " + objreader[3] + "<br><br>";
        //strCustDetails += "Status  - " + objreader[4] + "<br><br>";
        lblmsg.Text = strCustDetails;

        objConn.Close();
    }
    protected void GridView2_SelectedIndexChanging(Object sender, System.Web.UI.WebControls.GridViewSelectEventArgs e)
    {
        GridView2.PageIndex = e.NewSelectedIndex;
        GridView2.DataBind();
    }
}