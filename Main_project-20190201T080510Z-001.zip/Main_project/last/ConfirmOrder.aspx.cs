﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Net.Mail;
using System.Data;

public partial class ConfirmOrder : System.Web.UI.Page
{
    int cost, duration;
    string category_type;
    string category;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["name"] == null)
            Response.Redirect("login.aspx");
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        String str = "select c_email from reg where c_uname='" + Session["name"] + "'";
        SqlCommand cmd = new SqlCommand(str, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        txtcust_emailid.Text = ds.Tables[0].Rows[0]["c_email"].ToString();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        string cust_emailid = txtcust_emailid.Text.Trim();

        category = (DropDownList1.SelectedValue).ToString().Trim();
        category_type = (DropDownList2.SelectedValue).ToString().Trim();
       //int cost = TextBox2.Text;

        string event_date = Calendar1.SelectedDate.ToShortDateString();
        string event_address = txtevent_address.Text;
        string mobile_no = txtcontact_no.Text;

        string orderdetails = "Your orde details are as follows : <br>";
        orderdetails += "Category :" + category;
        orderdetails += "Category Type :" + category_type;
        orderdetails += "Event Date :" + event_date;
        orderdetails += "Event_Address :" + event_address;
        orderdetails += "Mobile No :" + mobile_no;
        orderdetails += "Cost :" + cost;
        orderdetails += "Duration :" + duration;

        string sqlInsert = @"insert into confirm_order(cust_emailid,category,category_name,cost,duration,event_date,event_address,mobile_no) values(@cust_emailid,@category,@category_name,@cost,@duration,@event_date,@event_address,@mobile_no)";
        SqlCommand com = new SqlCommand(sqlInsert, con);
        com.Connection = con;
        con.Open();

        com.Parameters.AddWithValue("@cust_emailid", cust_emailid);
        com.Parameters.AddWithValue("@category", category);
        com.Parameters.AddWithValue("@category_name", category_type);
        com.Parameters.AddWithValue("@cost", cost);
        com.Parameters.AddWithValue("@duration", duration);
        com.Parameters.AddWithValue("@event_date", event_date);
        com.Parameters.AddWithValue("@event_address", event_address);
        com.Parameters.AddWithValue("@mobile_no", mobile_no);




        Response.Write("<br><br><br><br><br><br><br><br><br><br><br><br>" + com);

        com.ExecuteNonQuery();
        com.Dispose();


        con.Close();



        MailMessage mail = new MailMessage();
        mail.To.Add(cust_emailid);
        mail.From = new MailAddress("creativephotographywebsite@gmail.com");
        mail.Subject = "Order Details";
        mail.Body = orderdetails;
        mail.IsBodyHtml = true;


        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        //'Or Your SMTP Server Address
        smtp.Credentials = new System.Net.NetworkCredential("creativephotographywebsite@gmail.com", "creative@2131");
        //Or your Smtp Email ID and Password
        smtp.EnableSsl = true;
        smtp.Send(mail);


        Response.Redirect("welcome.aspx");



    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        category = (DropDownList1.SelectedValue).ToString().Trim();
        category_type = (DropDownList2.SelectedValue).ToString().Trim();
        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");

        objConn.Open();
        SqlCommand cmd = new SqlCommand("Select * FROM book WHERE category=@category AND category_type=@category_type");

        cmd.Connection = objConn;

        cmd.Parameters.AddWithValue("@category", category);
        cmd.Parameters.AddWithValue("@category_type", category_type);

        SqlDataReader objreader = cmd.ExecuteReader();
        objreader.Read();

        cost = Convert.ToInt32(objreader[4]);
        duration = Convert.ToInt32(objreader[5]);

        TextBox2.Text = cost.ToString();
        TextBox3.Text = duration.ToString();
    }
    protected void TextBox6_TextChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}




