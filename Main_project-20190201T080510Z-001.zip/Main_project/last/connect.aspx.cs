﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Configuration;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
public partial class connect : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnRegSubmit_Click(object sender, ImageClickEventArgs e)
    {
        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        objConn.Open();
        SqlCommand cmd = new SqlCommand();
        cmd = objConn.CreateCommand();
        String strInsertQry;
        strInsertQry = "insert into Feedback(Fname,Fmail,Ffeedback) values (@Fname,@Fmail,@Ffeedback)";
        cmd.CommandText = strInsertQry;
        String Fname, Fmail, Ffeedback;


        Fname = txtName.Text;
        Fmail = txtMail.Text;
        Ffeedback = txtFeedback.Text;
        




        cmd.Parameters.AddWithValue("@Fname", Fname);
        cmd.Parameters.AddWithValue("@Fmail", Fmail);
        cmd.Parameters.AddWithValue("@Ffeedback", Ffeedback);
        

        cmd.ExecuteNonQuery();
        cmd.Dispose();
        objConn.Close();
        MailMessage mail = new MailMessage();
        mail.To.Add("creativephotographywebsite@gmail.com");
        mail.From = new MailAddress(Fmail);

        mail.Subject = "Feedback";
        mail.Body = (Ffeedback);
        mail.IsBodyHtml = true;


        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        //'Or Your SMTP Server Address
        smtp.Credentials = new System.Net.NetworkCredential("creativephotographywebsite@gmail.com", "creative@2131");
        //Or your Smtp Email ID and Password
        smtp.EnableSsl = true;
        smtp.Send(mail);

        Label1.ForeColor = Color.Aqua;
        Label1.Text = "Thank You for interacting with us...!!!";

    



 
    }

    



    protected void ClearALL()
    {
        txtMail.Text = "";
        txtFeedback.Text="";
         txtName.Text="";
        
   }

    protected void btnRegReset_Click(object sender, ImageClickEventArgs e)
    {
        ClearALL();
    }
}

