﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class viewdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        con.Open();
        lb1.Text = "<b><font color=Brown>" + "WELCOME:: " + "</font>" + "<b><font color=red>" + Session["name"] + "</font>";
        string str = ("select * from confirm_order where cust_emailid= '" +Session["email"] +" '");
        //where ='" + Session["name"] + "'";
        SqlCommand com = new SqlCommand(str, con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds);
        lbl_ordid.Text = ds.Tables[0].Rows[0]["ordid"].ToString();
        lbl_emailid.Text = ds.Tables[0].Rows[0]["cust_emailid"].ToString();
        lbl_category.Text = ds.Tables[0].Rows[0]["category"].ToString();
        lbl_category_name.Text = ds.Tables[0].Rows[0]["category_name"].ToString();
        lbl_cost.Text = ds.Tables[0].Rows[0]["cost"].ToString();
        lbl_duration.Text = ds.Tables[0].Rows[0]["duration"].ToString();
        lbl_date.Text = ds.Tables[0].Rows[0]["event_date"].ToString();
        lbl_add.Text = ds.Tables[0].Rows[0]["event_address"].ToString();
        lbl_mob.Text = ds.Tables[0].Rows[0]["mobile_no"].ToString();

        Response.Write("alert('DATA UPDATED')");
    }
}