﻿﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


public partial class changepassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnRegSubmit_Click(object sender, ImageClickEventArgs e)
    {


        SqlConnection objConn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        objConn.Open();
        SqlCommand cmd = new SqlCommand("Select COUNT(*)FROM reg WHERE c_uname='" + txtname.Text + "'and c_password='" + txtold.Text + "' ", objConn);
        cmd.Connection = objConn;


        if (txtnew.Text == txtconfirm.Text)
        {

            SqlCommand cmd1 = new SqlCommand("Update reg set c_password= '" + txtconfirm.Text + "' where c_password = '" + txtold.Text + "'", objConn);
            cmd1.ExecuteNonQuery();
            objConn.Close();
            Label1.Text = "Succefully Updated";
            Label1.ForeColor = System.Drawing.Color.Green;

        }
        txtname.Text = "";
        txtold.Text = "";
        txtnew.Text = "";
        txtconfirm.Text = "";

       

    }
}
