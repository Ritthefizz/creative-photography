﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Configuration;
using System.Drawing;


public partial class forget : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT c_fname,c_password FROM reg Where c_email= '" + TextBox1.Text + "'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
          /*  MailMessage mm = new MailMessage("sender@gmail.com", "receiver@gmail.com");

            mm.Subject = "Your Forgottn Password";

            mm.Body = "Hi,Your Username is: " + ds.Tables[0].Rows[0]["c_fname"] + "Your Password is: " + ds.Tables[0].Rows[0]["c_password"] + "";


            mm.IsBodyHtml = true;

            SmtpClient smtp = new SmtpClient();

            smtp.Host = "smtp.gmail.com";

            smtp.EnableSsl = true;

            System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();

            NetworkCred.UserName = "creativephotographywebsite@gmail.com";

            NetworkCred.Password = "creative@2131";

            smtp.UseDefaultCredentials = true;

            smtp.Credentials = NetworkCred;

            smtp.Port = 587;

            smtp.Send(mm);

            Label3.Text = "Password Recovery Information has been Sent SucessFully...Please Check Your mail";*/

            MailMessage mail = new MailMessage();
            mail.To.Add(TextBox1.Text);
            mail.From = new MailAddress("creativephotographywebsite@gmail.com");

            mail.Subject = "Password Recovery Information";
            mail.Body = ( "Hi,Your Username is: " + ds.Tables[0].Rows[0]["c_fname"] + "Your Password is: " + ds.Tables[0].Rows[0]["c_password"] + "");
            mail.IsBodyHtml = true;


            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            //'Or Your SMTP Server Address
            smtp.Credentials = new System.Net.NetworkCredential("creativephotographywebsite@gmail.com", "creative@2131");
            //Or your Smtp Email ID and Password
            smtp.EnableSsl = true;
            smtp.Send(mail);
              Label3.Text = "Password Recovery Information has been Sent SucessFully...Please Check Your mail";
            Label3.ForeColor = Color.Aqua;
        }
        else
        {

            Label2.Text = "Please Enter Your Registered Username.";

        }


    }
}
