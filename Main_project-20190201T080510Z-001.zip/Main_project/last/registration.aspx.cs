﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Configuration;
using System.Net.Mail;
using System.Data;

public partial class registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


    }
    protected void btnRegSubmit_Click(object sender, ImageClickEventArgs e)
    {

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\DELL\Documents\Visual Studio 2010\WebSites\last\App_Data\db.mdf;Integrated Security=True;User Instance=True");
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd = con.CreateCommand();
        String strInsertQry;
        strInsertQry = "insert into reg(c_fname,c_lname,c_address,c_mob,c_email,c_uname,c_password) values (@FName, @LName, @Address,@MobNo,@Email,@UserName,@Password)";
        cmd.CommandText = strInsertQry;
        String Fname, Lname, address, mobno, email, uname, passwd;


        Fname = txtFirstName.Text;
        Lname = txtLastName.Text;
        address = txtAddress.Text;
        mobno = txtMob.Text;
        email = txtEmail.Text;
        uname = txtUname.Text;
        passwd = txtPass.Text;

        //string orderdetails = "Your orde details are as follows : <br>";
        //orderdetails += "Fname :" + Fname;
        //orderdetails += "Lname  :" + Lname;
        //orderdetails += "address  :" + address;
        //orderdetails += "mobno :" + mobno;
        //orderdetails += " email :" + email;
        //orderdetails += "uname :" + uname;
        //orderdetails += "passwd :" + passwd;


        cmd.Parameters.AddWithValue("@FName", Fname);
        cmd.Parameters.AddWithValue("@LName", Lname);
        cmd.Parameters.AddWithValue("@Address", address);
        cmd.Parameters.AddWithValue("@MobNo", mobno);
        cmd.Parameters.AddWithValue("@Email", email);
        cmd.Parameters.AddWithValue("@UserName", uname);
        cmd.Parameters.AddWithValue("@Password", passwd);

        cmd.ExecuteNonQuery();
        
        cmd.Dispose();
        con.Close();


        MailMessage mail = new MailMessage();
        mail.To.Add(txtEmail.Text);
        mail.From = new MailAddress("creativephotographywebsite@gmail.com");
        mail.Subject = "creative photography";
        mail.Body = ("Dear user, U have been sucessfully Registered with Creative Photography... <br> Thank You");
        mail.IsBodyHtml = true;


        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        //'Or Your SMTP Server Address
        smtp.Credentials = new System.Net.NetworkCredential("creativephotographywebsite@gmail.com", "creative@2131");
        //Or your Smtp Email ID and Password
        smtp.EnableSsl = true;
        smtp.Send(mail);

        Label11.Text = ("Dear User Check your EMail for Further Details");
        // Response.Redirect("login.aspx");

    }


    protected void ClearALL()
    {

        txtAddress.Text = "";
        txtEmail.Text = "";
        txtFirstName.Text = "";
        txtLastName.Text = "";
        txtMob.Text = "";
        txtPass.Text = "";
        txtReenterPass.Text = "";
        txtUname.Text = "";



    }

    protected void btnRegReset_Click(object sender, ImageClickEventArgs e)
    {
        ClearALL();
    }
}

