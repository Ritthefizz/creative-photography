﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["name"] == null)
        {

            id1.Visible = true;
            id2.Visible = false;
            IB1.Visible = false;

        }
        else
        {
            id2.Visible = true;
            id1.Visible = false;
            IB1.Visible = true;
        }
        

    }
}